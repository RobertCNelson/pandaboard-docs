Date : 09/16/10 

ion Design Inc.
4410 Shoalwood
Austin, Texas  78756          
                  
Design Manager    : Darren Larson
                  : (512)260-5778
             Email: dlarson@iondsn.com
        Cell Phone: (512)850-7004

Designer Contact  : Hector M. Arredondo
                  : (512)260-5778	ext.105
            Email : hectora@iondsn.com

Job#  100915Tii1

README for 720-2152-002_GERBERS.zip

Files contained in the zip file:

README.1st      This file
tiilyr1.021   	Layer 1
tiilyr2.021     Layer 2
tiilyr3.021   	Layer 3
tiilyr4.021     Layer 4
tiilyr5.021   	Layer 5
tiilyr6.021     Layer 6
tiilyr7.021   	Layer 7
tiilyr8.021     Layer 8
tiismc.021   	Soldermask Layer 1 Side (Component)
tiisms.021    	Soldermask Layer 8 Side (Solder)
tiispc.021    	Solder Paste Layer 1 Side (for Assembly ONLY)(Ref.ONLY)
tiisps.021    	Solder Paste Layer 8 Side (for Assembly ONLY)(Ref.ONLY)
tiitslk.021 	Silk Screen Layer 1 side
tiibslk.021 	Silk Screen Layer 8 side
tiifab.021    	Fabrication Drawing Page 1(for Ref. ONLY)
tiiassy1.021    Assembly Drawing Page 1 (for Ref. ONLY)
tiiassy2.021    Assembly Drawing Page 2 (for Ref. ONLY)
ncdrill-1-8.drl 	Drill tape (through hole)
ncdrill-1-2.drl 	Drill tape (micro, Layers 1 through 2)
ncdrill-1-3.drl 	Drill tape (micro, Layers 1 through 3)
nc_param.txt 		Drill tape setup file
ncdrill.log    		Drill tape composite file (for Reference ONLY)
tii021.ipc     		IPC-D-356 netlist (for Checking ONLY)
art_param.txt  		Artwork Format File (for Ref. ONLY)
tiicen.021		Placement file for Assembly (for Ref. Only)
tiinet.021 		Allegro Netlist (for Ref. Only)


Notes:	PLEASE REVIEW FAB DRAWING FOR SPECIFIC REQUIREMENTS.